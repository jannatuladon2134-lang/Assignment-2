#include<stdio.h>
int main(){
long long  n;
printf("enter your n :   ");
scanf("%lld",&n);
int count =0;
while(n>0){
    n/=10;
    count++;
}
printf("%d",count);
return 0;

}
